#ifndef _SYSTEM_H_
#define _SYSTEM_H_

void delay_1ms();
void delay_ms();
void System_Init();





#endif