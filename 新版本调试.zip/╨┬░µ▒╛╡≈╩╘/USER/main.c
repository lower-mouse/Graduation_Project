#include "variable.h"

//uint8_t Check_Date;
 void main(void)
{
 System_Init();
  while (1)
  {  
      RTC_Serverce();  
      if(Halt_Flag == 0)
      {                                         
          WakeUp_DeInit();   
          halt();      
      }
      if(USART3_RX_STA & 0x80) 
      {
        Message_Serverce_Usart();
        USART3_RX_STA = 0;   
        memset(Usart3_RecvBuf, 0, sizeof(Usart3_RecvBuf));
      }
      if(USART1_RX_STA & 0x80)
      {
        if(strncmp((const char*)Usart1_RecvBuf,"TTM:CONNECTED",13)==0)
          u3_printf("connect\n");
        else if(strncmp((const char*)Usart1_RecvBuf,"TTM:DISCONNECT",14)==0)
          u3_printf("disconnect\n");
        else if(strncmp((const char*)Usart1_RecvBuf,"TTM:",4)==0)
        {
          pritnf_data(Usart1_RecvBuf);
          Halt_Flag = 0;
        }
        else
        {
          Message_Serverce_BLE();
        } 
          USART1_RX_STA = 0;    
        memset(Usart1_RecvBuf, 0, sizeof(Usart1_RecvBuf));
      } 
    }
}
















