#ifndef _adc_H
#define _adc_H
#include "stm8l15x.h"
void Adc_Init(void);
void ADC_Get();
float ADC_Show();
void power_down_save();
void power_down_recover();
void power_down_check();
void low_power();
void Reset_Detection();//�ϵ���
#endif 