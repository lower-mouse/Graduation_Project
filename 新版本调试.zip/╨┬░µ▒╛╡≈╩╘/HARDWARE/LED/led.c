#include "variable.h"
void LedInit(void)//LED��ʼ��
{
  GPIO_Init(LED, LED_PIN, GPIO_Mode_Out_PP_Low_Fast);  
  GPIO_ResetBits(LED, LED_PIN);
}


